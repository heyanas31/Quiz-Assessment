#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

#define PORT	8080 
#define MAXLINE 1024 
#define BIGLINE 4096

void Showtest(int UserCourse,int newfd) // GETTING QUIZ FROM FILE AND SEND TO USER
{
    if(UserCourse != 0)
    {
        FILE * testfile;
        char Quiz[BIGLINE];
        if(UserCourse==1)
	    {
		    testfile= fopen("CCNquiz.txt","r");
	    }
	    if(UserCourse==2)
	    {
		    testfile= fopen("DSquiz.txt","r");
	    }
	    if(UserCourse==3)
	    {
	        testfile= fopen("OOPquiz.txt","r");
	    }

        fread(Quiz, sizeof(char), sizeof(Quiz) - 1, testfile);
	    fclose(testfile);
	    Quiz[sizeof(Quiz) - 1] = '\0';
	    send(newfd, (const char *)Quiz, strlen(Quiz),0);
        memset(Quiz,0,BIGLINE);
    }
}

int CalculateCCN(char * userans)  // CHECKING USER ANS
{
    int marks = 0;
    char correctAnswers[6] = {'a', 'c', 'b', 'b', 'a'};
    for (int i = 0; i < 5; i++)
    {
        if (userans[i] == correctAnswers[i])
        {
            marks += 1;
        }
    }
    return marks;
}

int CalculateDS(char * userans) // CHECKING USER ANS
{
	int marks = 0;
    char correctAnswers[6] = {'b', 'a', 'b', 'a', 'c'};
    for (int i = 0; i < 5; i++)
    {
        if (userans[i] == correctAnswers[i])
        {
            marks += 1;
        }
    }
    return marks;
}
int CalculateOOP(char * userans)  // CHECKING USER ANS
{
	int marks = 0;
    char correctAnswers[6] = {'b', 'a', 'c', 'c', 'a'};
    for (int i = 0; i < 5; i++)
    {
        if (userans[i] == correctAnswers[i])
        {
            marks += 1;
        }
    }
    return marks;
}

void StoreData(char *rollno, int marks[])
{
    FILE *f;
    f = fopen("StudentMarks.csv","a");
    fprintf(f,"\n%s,%d,%d,%d",rollno,marks[0],marks[1],marks[2]);
    fclose(f);
}