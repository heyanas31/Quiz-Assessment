#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 

void ServerLogo()
{
    printf("\n\t*******************************************************************\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t              <-- SERVER IS ON -->                      ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t*******************************************************************\n\n");
}
const char* CheckID(const char *ID)  // CHECKING USER ID
{
	if(strcmp(ID,"l1f22bscs1070") == 0)
	{
		return "1";
	}
	if(strcmp(ID,"l1f22bscs1071") == 0)
	{
		return "1";
	}
	if(strcmp(ID,"l1f22bscs1072") == 0)
	{
		return "1";
	}
	else
	{
		return "ERROR= ID not found, TRY AGAIN!";
	}
}
const char* CheckPass(const char *ID,const char * Pass) // CHECKING USER PASSWORD
{
	if(strcmp(ID,"l1f22bscs1070") == 0 && strcmp(Pass,"anas1122")==0)
	{
		return "1";
	}
	if(strcmp(ID,"l1f22bscs1071") == 0 && strcmp(Pass,"ayesha1122")==0)
	{
		return "1";
	}
	if(strcmp(ID,"l1f22bscs1072") == 0 && strcmp(Pass,"hassan1122")==0)
	{
		return "1";
	}
	else
	{
		return "ERROR= Wrong Password, TRY AGAIN!";
	}
}	