#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#define PORT	 8080 
#define MAXLINE 1024 
#define BIGLINE 4096

void CoursesOption()
{
    printf("\t*******************************************************************\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t               <-- SELECT COURSES -->                   ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t*******************************************************************\n");
	printf("\t1) Computer Communication & Network\n\t2) Data Structures\n\t3) Object Oriented Programming\n\n");
}

void ProjectLabel()
{
    printf("\t*******************************************************************\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t          <-- QUIZ ASSESSMENT SYSTEM -->                ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t*******************************************************************\n\n");
	printf("\t*******************************************************************\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t             <-- PROVIDE LOGIN INFO -->                 ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t*******************************************************************\n");
}

void QuizLabel(int i)
{
	printf("\n\t*******************************************************************\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t                   <-- QUIZ %d -->                       ***\n",i);
	printf("\t***\t\t                                                ***\n");
	printf("\t*******************************************************************\n");
}

void ResultLabel()
{
	printf("\n\t*******************************************************************\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t***\t                   <-- RESULT -->                       ***\n");
	printf("\t***\t\t                                                ***\n");
	printf("\t*******************************************************************\n");
}