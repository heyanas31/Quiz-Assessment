#include"LoginSYS.h"
#include"QuizSYS.h"

int main() 
{ 
	int sockfd; 
	struct sockaddr_in servaddr, cliaddr; 
	
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) // MAKING SOCKET 
	{ 
		perror("Socket creation failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	memset(&servaddr, 0, sizeof(servaddr)); 
	memset(&cliaddr, 0, sizeof(cliaddr)); 
	
	// ADDING INFO FOR CONNECTION
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT); 
	// SOCKET BINDING
	if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) 
	{ 
		perror("Bind failed"); 
		exit(EXIT_FAILURE); 
	} 
	listen(sockfd, 5);
	
	ServerLogo();
	char UserID[MAXLINE];
	char UserPass[MAXLINE]; 
	const char *loginInfo; 
	while (1)  // SERVER WILL ALWAYS ON
	{
		socklen_t len = sizeof(cliaddr); 
		int newfd = accept(sockfd, (struct sockaddr*)&cliaddr, &len); // MAKING NEWFD TCP CONCURRENT
		if (newfd < 0) 
		{
			perror("Accept failed");
			continue;
		}
		int pid = fork(); // MAKING 2 PROCESSES
		if (pid == 0) 
		{  
			close(sockfd); 
			char ip[INET_ADDRSTRLEN];
			inet_ntop(AF_INET, &(cliaddr.sin_addr), ip, INET_ADDRSTRLEN);
			while(1)
			{
				int n = recv(newfd, UserID, MAXLINE, 0);  // RECIEVE USER ID FROM CLIENT
				UserID[n] = '\0';
				loginInfo = CheckID(UserID); 
				printf("\tClient [%d] sent: %s\n",ntohs(cliaddr.sin_port), UserID);
				send(newfd, loginInfo, strlen(loginInfo), 0); 
				if(strcmp(loginInfo,"1")==0)  // ID IS CORRECT
				{
					break;
				}
				printf("\tClient [%d] send: Wrong ID!\n\n",ntohs(cliaddr.sin_port));
			}
			while(1)
			{
				int n = recv(newfd, UserPass, MAXLINE, 0);  // RECEIVE USER PASS FROM CLIENT 
				UserPass[n] = '\0';
				loginInfo = CheckPass(UserID,UserPass); // CHECK USER PASS
				printf("\tClient [%d] sent: %s\n",ntohs(cliaddr.sin_port), UserPass);
				send(newfd, loginInfo, strlen(loginInfo), 0); 
				if(strcmp(loginInfo,"1")==0) // PASS IS CORRECT
				{
					break;
				}
				printf("\tClient [%d] send: Wrong Password!\n\n",ntohs(cliaddr.sin_port));
			}

			int UserCourses[4]={0,0,0,0};
			printf("\tClient [%d] send: LOGIN SUCCESSFUL\n",ntohs(cliaddr.sin_port));
			recv(newfd, UserCourses,sizeof(UserCourses), 0);  // RECEIVING COURSES THAT USER SELECTED 
			printf("\tClient [%d] selected Courses: ",ntohs(cliaddr.sin_port));
			int i=0;
			while(UserCourses[i]!=0)
			{
				printf("%d ",UserCourses[i]);
				i++;
			}
			printf("\n");

			int j=0;
			char bufferAns[MAXLINE];
			int Usermarks[3]={0,0,0};
			while(UserCourses[j]!=0)
			{
				Showtest(UserCourses[j],newfd); // SEND QUIZ Qs TO CLIENT
				printf("\tClient [%d]: Quiz %d send\n",ntohs(cliaddr.sin_port),UserCourses[j]);
				int n = recv(newfd, bufferAns, MAXLINE, 0); // RECEIVE ANS
				bufferAns[n] = '\0';
				printf("\tClient [%d] : ANSWERS RECEIVED\n",ntohs(cliaddr.sin_port));
				if(UserCourses[j]==1)
				{
					//CCN MARKS
					Usermarks[j]= CalculateCCN(bufferAns);
				}
				if(UserCourses[j]==2)
				{
					//DS MARKS
					Usermarks[j]= CalculateDS(bufferAns);
				}
				if(UserCourses[j]==3)
				{
					//OOP MARKS
					Usermarks[j]= CalculateOOP(bufferAns);
				}
				j++;
			}
			send(newfd, Usermarks, sizeof(Usermarks), 0);
			
			// STORE MARKS IN .CSV FILE
			StoreData(UserID,Usermarks);
	
			printf("\tClient [%d] : Result Sent & Stored\n",ntohs(cliaddr.sin_port));
			close(newfd);
			exit(0);
		} 
		else if (pid > 0) 
		{
			close(newfd);
		} 
		else 
		{
			perror("Fork failed");
		}
	}
	
	return 0; 
}
