#include"CouseSelect.h"

int main() 
{ 
	int sockfd; 
	struct sockaddr_in servaddr; 
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)  // CREATING SOCKET
	{ 
		perror("Socket creation failed"); 
		exit(EXIT_FAILURE); 
	} 

	memset(&servaddr, 0, sizeof(servaddr)); 

	// ADDING SERVER INFO
	servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr.s_addr = INADDR_ANY; 

	// MAKING CONNECTION FOR TCP
	if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) 
	{
		perror("Connection failed");
		exit(EXIT_FAILURE);
	}

	ProjectLabel(); // DISPLAY PROJECT LABEL
		
	char buffer[MAXLINE]; 
	char ID[MAXLINE];
	char Pass[MAXLINE];  
	while(1)  // GET USER ID WITH ERROR HANDLING
	{
		printf("\tEnter UCP ID: ");
		fgets(ID, MAXLINE, stdin);
		ID[strcspn(ID, "\n")] = '\0';
		send(sockfd, ID, strlen(ID), 0); // SENDING USER ID TO SERVER
		int n = recv(sockfd, buffer, MAXLINE, 0); // RECEIVING 1 IF ID IS CORRECT 
		buffer[n] = '\0';
		if(strcmp(buffer,"1") == 0)
		{
			break;
		}
		else
		{
			printf("\tServer [Port %d]: %s\n\n", PORT, buffer);	// IF ID IS WRONG
		}
	}
	
	while(1)   // GET USER PASS WITH ERROR HANDLING
	{
		printf("\tEnter Password: ");
		fgets(Pass, MAXLINE, stdin);
		Pass[strcspn(Pass, "\n")] = '\0'; 
		send(sockfd, Pass, strlen(Pass), 0); // SENDING USER PASS TO SERVER
		int n = recv(sockfd, buffer, MAXLINE, 0); // RECEIVING 1 IF PASS IS CORRECT
		buffer[n] = '\0';
		if(strcmp(buffer,"1") == 0) 
		{
			break;
		}
		else
		{
			printf("\tServer [Port %d]: %s\n\n", PORT, buffer);	// IF PASS IS WRONG
		}
	}
	printf("\n\t***\t              <-- LOGIN SUCCESSFUL -->                  ***\n\n");
	
	CoursesOption();  	// DISPLAY COURSES INFO TO USER
	
	int totalCourses,SelectCourses[3];
	while(1)
	{
		printf("\tHow many courses you want for Quiz: ");  // GET TOTAL No. OF QUIZ USER WANT
		scanf("%d",&totalCourses);
		if(totalCourses<=3 && totalCourses>=1)
		{
			for(int i =0; i < totalCourses;i++)  
			{
				printf("\tEnter Serial no. of course: "); // GET COURSES FOR QUIZ
				scanf("%d",&SelectCourses[i]);
				if(SelectCourses[i]!=1 && SelectCourses[i]!=2 && SelectCourses[i]!=3)
				{
					printf("\tERROR= Wrong Input, TRY AGAIN!\n\n");
					i--;
				}
			}
			break;
		}
		printf("\tERROR= Wrong Input, TRY AGAIN!\n\n");
	}
	// SENDING SELECTED COURSES INFO TO SERVER FOR QUIZ
	send(sockfd, SelectCourses, sizeof(SelectCourses), 0); 

	char Quiz[BIGLINE];
	char answers[10];
	int n=0;
	for(int i=0; i<totalCourses; i++)  // GET USER Qs/As
	{
		QuizLabel(i+1); // DISPLAY QUIZ LABEL
		n = recv(sockfd, (char *)Quiz, BIGLINE, 0);  // RECEIVING QUIZ Qs
		Quiz[n] = '\0';
		printf("%s\n\n",Quiz);
		
		printf("\t***\t           <-- PROVIDE ANSWERS(a,b,c) -->               ***\n\n");
		for(int j=0;j<5;j++)
		{
			while(1)  // TAKING ANSWERS
			{
				printf("\t%d) ",j+1);
				scanf(" %c",&answers[j]);
				if(answers[j]>='a' && answers[j]<'d') // INPUT ERROR CHECKING
				{
					break;
				}
				printf("\tERROR= Wrong Input, TRY AGAIN!\n");
			}
			printf("\n");
		}
		send(sockfd, answers, strlen(answers), 0);  // SENDING ANSWERS TO SERVER
		memset(answers,0,MAXLINE); 
	}
	
	int markbuffer[3];
	recv(sockfd, markbuffer,sizeof(markbuffer), 0);  // RECEIVE RESULT FROM SERVER

	ResultLabel();  // DISPLAY RESULT LOGO
	for(int i=0;i<3;i++)  // DISPLAY RESULT
	{
		if(SelectCourses[i]==1)
		{
			printf("\tComputer Communication & Network Marks: %d/5\n\n",markbuffer[i]);
		}
		if(SelectCourses[i]==2)
		{
			printf("\tData Structures Marks: %d/5\n\n",markbuffer[i]);
		}
		if(SelectCourses[i]==3)
		{
			printf("\tObject Oriented Programming Marks: %d/5\n\n",markbuffer[i]);
		}
	}
	close(sockfd); // CLOSE SOCKET
	return 0; 
}
